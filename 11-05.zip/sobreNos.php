<?php
    include ('cabeca.php');
?>

<div class="informacoes">
    INFORMAÇÕES
</div>

<?php
    include ('rodape.php');
?>