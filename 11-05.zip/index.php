<?php
    include ('cabeca.php');
?>

<div class="home">
    HOME
</div>

<?php
    include ('rodape.php');
?>