<?php
    include ('cabeca.php');
?>

<div class="cardapio">
    CARDAPIO
</div>

<?php
    include ('rodape.php');
?>