<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>IF Food</title>
</head>

<body>

    <div class="cabecalho">
        <div class="menu">
            MENU
        </div>

        <div class="banner">
            <div class="main">
                <div>
                    <p>BANNER</p>
                </div>
                <div class="pesquisa">
                    <input type="text" placeholder='PESQUISAR...'>
                </div>
            </div>
        </div>

    </div>