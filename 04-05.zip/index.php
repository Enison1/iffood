<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>IF Food</title>
</head>

<body>

    <div class="cabecalho">
        <div class="menu">
            MENU
        </div>
        <div class="pesquisa">
            PESQUISAR
        </div>
        <div class="banner">
            BANNER
        </div>
        
    </div>

    <div class="texto">
        <div class="apresentacao">
            APRESENTAÇÃO
        </div>
        <div class="cardapio">
            CARDAPIO
        </div>
    </div>

    <div class="rodape">
        RODAPÉ
    </div>
</body>

</html>